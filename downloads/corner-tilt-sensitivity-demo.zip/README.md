# Corner Tilt Sensitivity Demo Package

## English

This public demo package was prepared for the website and is safe to share publicly.

Included:
- summary PDF
- preview images
- selected sample data where available
- public package note

Public scope:
- preview-level materials only
- no full production drawings
- no full customer package

Full engineering packages can be prepared separately after project scoping.

## עברית

חבילת ה-demo הזו הוכנה עבור האתר ובטוחה לשיתוף ציבורי.

מה כלול:
- PDF מסכם
- תמונות preview
- נתוני דוגמה נבחרים כאשר הם זמינים
- הערת scope ציבורית

תחום החבילה הציבורית:
- חומרי preview בלבד
- ללא שרטוטי ייצור מלאים
- ללא חבילת לקוח מלאה

חבילה הנדסית מלאה יכולה להיבנות בנפרד לאחר הגדרת סקופ.
